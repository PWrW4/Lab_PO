package laboratory.shape;

import laboratory.velocity.VelocityVector;

/**
 * Created by wojtasiq on 09.06.2017.
 */
public class Mover {
    public void move(MyShape shape, VelocityVector velocityVector) {

    }
}
