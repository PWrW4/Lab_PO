package laboratory.shape;

import java.util.Random;

/**
 * Created by wojtasiq on 09.06.2017.
 */
public class Resizer {

    private final Random rand = new Random();

    public static void randomResize(MyShape shape) {

    }
}
