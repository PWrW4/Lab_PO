package notGui;
import javafx.scene.canvas.GraphicsContext;

/**
 * Created by wojtasiq on 09.06.2017.
 */
public interface Drawable {
    abstract void draw();
}
