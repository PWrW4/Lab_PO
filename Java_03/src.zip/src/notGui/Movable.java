package notGui;

/**
 * Created by wojtasiq on 09.06.2017.
 */
public interface Movable {
    void move(int x, int y);
}
