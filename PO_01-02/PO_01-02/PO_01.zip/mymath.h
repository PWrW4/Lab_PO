#pragma once
#include <iostream>

using std::cout;
using std::cin;
using std::endl;

void primeNumbers(int n);
bool isPrime(int i);
void factorial(int n);
int silnia(int n);
int fibonaci(int n);
int fib(int n);